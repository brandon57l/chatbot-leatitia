import os
import json
from flask import Flask, render_template, request, jsonify, send_from_directory
import requests

app = Flask(__name__)

# Récupération de la clé API depuis l'environnement (ou mettez-la en dur pour tester)
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyBiZONd6VA8y9zAd8vueZRo_IrPnn7iHlw")  # Remplacez par votre clé
# URL de l'API Gemini avec la clé
GEMINI_API_ENDPOINT = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GEMINI_API_KEY}"

@app.route("/")
def index():
    # On passe une liste vide pour le premier rendu ; la conversation se gère côté client ensuite
    return render_template("chat.html", messages=[])

@app.route('/send_message', methods=['POST'])
def send_message():
    # Récupérer le message et l'historique envoyé par le client
    message = request.form.get('message')
    history = request.form.get('history')
    
    # Convertir l'historique en liste d'objets (s'il existe)
    conversation_history = json.loads(history) if history else []
    
    # Ajouter le message de l'utilisateur à l'historique (seul le texte est conservé pour l'API)
    conversation_history.append({'text': message})
    
    # Préparer la requête à l'API Gemini en envoyant tout l'historique
    headers = {'Content-Type': 'application/json'}

    with open("context.txt", "r", encoding="utf-8") as fichier:
        context = fichier.read()

    data = {
        "contents": [
            {
                "role": "model",
                "parts": [{"text": context}]  # Le contexte ajouté ici
            },
            {
                "role": "user",  # Message de l'utilisateur
                "parts": [{"text": msg['text']} for msg in conversation_history]  # Historique des messages
            }
        ]
    }
    
    try:
        response = requests.post(GEMINI_API_ENDPOINT, json=data, headers=headers)
        gemini_response = response.json()
        
        print(gemini_response)  # Debug pour voir la vraie structure

        if isinstance(gemini_response, dict) and "candidates" in gemini_response:
            candidates = gemini_response["candidates"]
            
            if isinstance(candidates, list) and len(candidates) > 0:
                content = candidates[0].get("content")
                
                # Vérifie si content est une simple string ou un objet
                if isinstance(content, dict) and "parts" in content:
                    text_value = content["parts"][0].get("text", "Réponse vide.")
                elif isinstance(content, str):
                    text_value = content
                else:
                    text_value = "Réponse inattendue."

                response_text = {"parts": [{"text": text_value}]}
            else:
                response_text = {"parts": [{"text": "Aucune réponse valide reçue de l'IA."}]}
        else:
            response_text = {"parts": [{"text": "Réponse inattendue du serveur."}]}

    except Exception as e:
        print(f"Erreur : {e}")  # Debug pour voir l'erreur
        response_text = {"parts": [{"text": "Nous rencontrons actuellement un problème technique. Veuillez réessayer plus tard. Merci pour votre patience !"}]}

    # Retourner la réponse et l'historique
    return jsonify({'gemini_response': response_text, 'history': conversation_history})

@app.route('/IMG/<path:filename>')
def serve_image(filename):
    return send_from_directory(os.path.join(app.root_path, 'static'), filename)


if __name__ == '__main__':
    app.run(debug=True)
